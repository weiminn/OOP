public class VehicleTest {
    public static void main(String[] args) {
        Motorcycle motorcycle = new Motorcycle(30);
        Car car = new Car(15);

        System.out.println(motorcycle.toString());
        System.out.println(car.toString());
    }
    
}
