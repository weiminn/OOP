public class Motorcycle extends Vehicle{
    public Motorcycle(double distancePerLiter) {
        super(2, distancePerLiter);
    }
    
    // @Override
    // public String toString() {
    //     return String.format("Vehicle[numWheels='%d', distancePerLiter=%.1f]", numWheels, distancePerLiter);
    // }
}
