

public class ResultGenerator {

}
