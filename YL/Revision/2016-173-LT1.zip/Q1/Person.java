import java.util.*;

public class Person {
    // Do not change : start
    private String name;
    private List<Item> items = new ArrayList<>();
    
    public Person(String name) {
        this.name = name;
    }
    
    public void addItem(Item item) {
        items.add(item);
    }
    
    public String toString() {
        return name + " " + items;
    }
    // Do not change : end
    
   
       
    
    
}