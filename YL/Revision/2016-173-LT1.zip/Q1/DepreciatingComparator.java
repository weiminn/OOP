import java.util.*;

public class DepreciatingComparator  {
}