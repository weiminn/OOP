package smu.object;

public class Venue {
}