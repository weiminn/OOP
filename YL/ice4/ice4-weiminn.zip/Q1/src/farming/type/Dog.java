package farming.type;

public class Dog implements Animal {
    public void makeNoise() {
        System.out.println("woof woof");
    }
}
