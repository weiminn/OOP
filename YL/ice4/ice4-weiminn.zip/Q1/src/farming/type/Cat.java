package farming.type;

public class Cat implements Animal {
    public void makeNoise() {
        System.out.println("meow meow");
    }
}
