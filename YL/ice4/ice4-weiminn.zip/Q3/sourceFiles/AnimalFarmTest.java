import farming.*;

public class AnimalFarmTest {
    public static void main(String[] args) {
        AnimalFarm farm = new AnimalFarm();
        farm.makeNoise();
    }
}
