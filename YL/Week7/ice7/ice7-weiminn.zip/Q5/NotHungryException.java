public class NotHungryException extends Exception {

    public NotHungryException(String message) {
        super(message);
    }
    
}
