public class DataException extends RuntimeException {

    public DataException(String msg) {
        super(msg);
    }
    
}
