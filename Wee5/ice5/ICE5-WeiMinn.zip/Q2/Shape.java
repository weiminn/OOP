package ice5.Q2;

public interface Shape {
    double getArea();
    double getPerimeter();
    
}
