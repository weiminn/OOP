package ice5.Q2;

public class Test {
    public static void main(String[] args) {
        Octagon oct = new Octagon(12);
        System.out.println("Area: " + oct.getArea());
        System.out.println("Peri: " + oct.getPerimeter());
    }
    
}
