// this is for Q7
public class Person {


}