public class ShirtTest {
    public static void main(String[] args) {

    }
}
