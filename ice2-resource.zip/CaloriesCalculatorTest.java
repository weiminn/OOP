public class CaloriesCalculatorTest {
    public static void main(String[] args) {


    }
}
