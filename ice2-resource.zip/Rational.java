
public class Rational {

}